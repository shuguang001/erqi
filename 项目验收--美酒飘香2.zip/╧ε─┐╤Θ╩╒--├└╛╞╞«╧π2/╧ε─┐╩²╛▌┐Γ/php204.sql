/*
Navicat MySQL Data Transfer

Source Server         : my数据库
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : php204

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-08-08 18:52:21
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for addresss
-- ----------------------------
DROP TABLE IF EXISTS `addresss`;
CREATE TABLE `addresss` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sheng` varchar(255) DEFAULT NULL,
  `shi` varchar(255) DEFAULT NULL,
  `xian` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `uname` varchar(255) DEFAULT NULL,
  `shouji` varchar(255) DEFAULT NULL,
  `dianhua` varchar(255) DEFAULT NULL,
  `youbian` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT '0',
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of addresss
-- ----------------------------
INSERT INTO `addresss` VALUES ('18', '湖南省', '常德市', '津市市', '长寿街道', '2018-07-28 22:08:35', '2018-07-28 22:08:36', null, 'tangyue1', '15032071336', '18832326593', '123456', '1', '61');
INSERT INTO `addresss` VALUES ('19', '辽宁省', '沈阳市', '康平县', '123', '2018-07-29 00:58:23', '2018-07-29 09:07:39', null, 'aaa', '15032071336', '18832326593', '123456', '0', '59');
INSERT INTO `addresss` VALUES ('20', '河北省', '石家庄市', '新乐市', '长寿街道', '2018-07-29 09:07:21', '2018-07-29 09:07:40', null, '唐大大', '15032071336', '18832326593', '123456', '1', '59');
INSERT INTO `addresss` VALUES ('21', '河南省', '新乡市', '封丘县', '123456', '2018-07-29 20:22:56', '2018-07-29 20:22:57', null, 'xueyanfeng', '15032071336', '18832326593', '123456', '1', '63');
INSERT INTO `addresss` VALUES ('23', '湖南省', '岳阳市', '临湘市', 'asd ', '2018-07-30 04:19:23', '2018-07-30 04:19:24', null, 'gejingwei', '15032071336', '18832326593', '123456', '1', '50');
INSERT INTO `addresss` VALUES ('27', '湖北省', '随州市', '广水市', '你猜那个街道', '2018-08-02 09:07:59', '2018-08-02 09:07:59', null, '薛艳峰', '15032071336', '18832326593', '123', '1', '49');
INSERT INTO `addresss` VALUES ('28', '山西省', '吕梁市', '柳林县', '柳林镇', '2018-08-03 15:55:53', '2018-08-03 15:56:54', null, '薛艳峰', '13353588574', '03584012345', '033300', '1', '56');
INSERT INTO `addresss` VALUES ('29', '广东省', '江门市', '鹤山市', '雪雁', '2018-08-07 10:59:17', '2018-08-07 10:59:46', null, '唐跃', '17635862346', '', '012345', '0', '49');
INSERT INTO `addresss` VALUES ('30', '甘肃省', '定西市', '陇西县', '长寿街道', '2018-08-07 11:49:15', '2018-08-07 11:49:16', null, '唐小', '18832326593', '88537521', '12345', '1', '60');
INSERT INTO `addresss` VALUES ('38', '甘肃省', '酒泉市', '肃北蒙古族自治县', 'jh', '2018-08-07 15:58:24', '2018-08-07 15:58:24', null, 'zhangshuguang', '1111111111', '', '000000', '1', '65');
INSERT INTO `addresss` VALUES ('39', '北京市', '市辖区', '昌平区', '23432432', '2018-08-07 16:51:11', '2018-08-07 16:51:12', null, 'zhangshuguang', '1111111111', '123343554', '123145', '1', '68');
INSERT INTO `addresss` VALUES ('40', '江西省', '赣州市', '信丰县', '长寿街道', '2018-08-07 19:29:02', '2018-08-07 19:29:03', null, '唐跃', '15032071336', '18832326593', '123456', '1', '69');
INSERT INTO `addresss` VALUES ('41', '辽宁省', '沈阳市', '康平县', 'zsg', '2018-08-07 19:51:16', '2018-08-07 19:51:16', null, 'zsg', '15032071336', '18832326593', '123456', '1', '70');
INSERT INTO `addresss` VALUES ('42', '吉林省', '白城市', '大安市', '长寿街道', '2018-08-07 20:06:58', '2018-08-08 09:07:00', null, '薛老板', '15032071336', '18832326593', '123456', '1', '72');

-- ----------------------------
-- Table structure for advers
-- ----------------------------
DROP TABLE IF EXISTS `advers`;
CREATE TABLE `advers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `advername` varchar(255) DEFAULT NULL,
  `path` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `profile` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `status` varchar(10) CHARACTER SET latin1 DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `weizhi` varchar(10) DEFAULT NULL COMMENT '1 左 2中 3右',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of advers
-- ----------------------------
INSERT INTO `advers` VALUES ('27', '阿萨德1', 'baidu', 'Rg0QnXvCz8.Rg0QnXvCz8', '1', '2018-08-07 22:17:57', '2018-08-03 09:52:21', '2');
INSERT INTO `advers` VALUES ('26', '风景2', '0', 'so9eCwGuVO.jpg', '2', '2018-08-08 09:03:58', '2018-08-03 09:51:26', '1');
INSERT INTO `advers` VALUES ('25', '风景', 'baidu', 'wz9PR2Xcpf.jpg', '1', '2018-08-03 14:18:03', '2018-08-03 09:50:42', '3');
INSERT INTO `advers` VALUES ('29', '阿萨德', 'baidu', 'iijUeRQMmo.jpg', '1', '2018-08-08 09:03:18', '2018-08-08 09:03:18', '1');

-- ----------------------------
-- Table structure for carousels
-- ----------------------------
DROP TABLE IF EXISTS `carousels`;
CREATE TABLE `carousels` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `describe` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of carousels
-- ----------------------------
INSERT INTO `carousels` VALUES ('42', '111', 'vS8ZDQDXl2lr7S7HbJhd.jpg', '嗯哼哼', '2018-08-07 10:58:21', '2018-08-07 10:58:21', null, 'https://www.baidu.com');
INSERT INTO `carousels` VALUES ('39', '唐月', 'DeIhv9gDeqRxDmuu62Hv.jpg', '1111', '2018-07-09 09:20:32', '2018-07-23 10:28:30', null, '');
INSERT INTO `carousels` VALUES ('40', '333', 'P4r3aVfHe0nDJwP66eAN.jpg', 'kjkj', '2018-07-09 09:23:03', '2018-07-23 10:28:40', null, '');
INSERT INTO `carousels` VALUES ('43', '好的', '3qGYfmYVzPs4ih06IODO.jpg', 'jwafjw', '2018-08-07 14:56:59', '2018-08-07 14:56:59', null, 'http://www.baidu.com');
INSERT INTO `carousels` VALUES ('44', '美酒飘香1', 'OtpoUJYltUhpgNlPMFMd.jpg', '玩法无法', '2018-08-07 15:46:26', '2018-08-07 15:46:26', null, 'http://www.baidu.com');

-- ----------------------------
-- Table structure for cates
-- ----------------------------
DROP TABLE IF EXISTS `cates`;
CREATE TABLE `cates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cname` varchar(255) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `path` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `status` varchar(255) CHARACTER SET latin1 DEFAULT '1' COMMENT '1是开启 2是禁用',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cates
-- ----------------------------
INSERT INTO `cates` VALUES ('30', '家具', '0', '0', '1', '2018-08-01 16:11:59', '2018-08-01 16:11:59', null);
INSERT INTO `cates` VALUES ('31', '沙发', '30', '0,30', '1', '2018-08-07 18:24:51', '2018-08-01 16:12:11', null);
INSERT INTO `cates` VALUES ('32', '单人沙发', '31', '0,30,31', '1', '2018-08-07 18:56:23', '2018-08-01 16:12:30', null);
INSERT INTO `cates` VALUES ('33', '双人沙发', '31', '0,30,31', '1', '2018-08-01 16:12:47', '2018-08-01 16:12:47', null);
INSERT INTO `cates` VALUES ('35', '数码', '0', '0', '1', '2018-08-01 17:07:36', '2018-08-01 17:07:36', null);
INSERT INTO `cates` VALUES ('37', '电视', '35', '0,35', '1', '2018-08-01 17:08:17', '2018-08-01 17:08:17', null);
INSERT INTO `cates` VALUES ('38', '55寸海尔', '37', '0,35,37', '1', '2018-08-01 17:08:40', '2018-08-01 17:08:40', null);
INSERT INTO `cates` VALUES ('40', '衣服', '0', '0', '1', '2018-08-01 17:15:04', '2018-08-01 17:15:04', null);
INSERT INTO `cates` VALUES ('41', '男人', '40', '0,40', '1', '2018-08-01 17:15:17', '2018-08-01 17:15:17', null);
INSERT INTO `cates` VALUES ('42', '短袖', '41', '0,40,41', '1', '2018-08-01 17:15:30', '2018-08-01 17:15:30', null);
INSERT INTO `cates` VALUES ('43', '衬衫', '41', '0,40,41', '1', '2018-08-01 17:15:50', '2018-08-01 17:15:50', null);
INSERT INTO `cates` VALUES ('44', '电子', '0', '0', '1', '2018-08-07 17:12:44', '2018-08-07 17:12:44', null);
INSERT INTO `cates` VALUES ('45', '电脑', '44', '0,44', '1', '2018-08-07 17:12:54', '2018-08-07 17:12:54', null);
INSERT INTO `cates` VALUES ('46', '戴尔电脑', '45', '0,44,45', '1', '2018-08-07 17:13:05', '2018-08-07 17:13:05', null);
INSERT INTO `cates` VALUES ('56', '联想电脑', '45', '0,44,45', '1', '2018-08-07 21:33:02', '2018-08-07 21:33:02', null);
INSERT INTO `cates` VALUES ('54', '柜子', '30', '0,30', '1', '2018-08-07 21:14:58', '2018-08-07 21:14:58', null);
INSERT INTO `cates` VALUES ('55', '单人柜子', '54', '0,30,54', '1', '2018-08-07 21:23:35', '2018-08-07 21:23:35', null);
INSERT INTO `cates` VALUES ('57', '手机', '35', '0,35', '1', '2018-08-07 21:33:32', '2018-08-07 21:33:32', null);
INSERT INTO `cates` VALUES ('58', '小米手机', '57', '0,35,57', '1', '2018-08-07 21:33:44', '2018-08-07 21:33:44', null);
INSERT INTO `cates` VALUES ('59', '女人', '40', '0,40', '1', '2018-08-08 09:01:57', '2018-08-08 09:01:57', null);
INSERT INTO `cates` VALUES ('60', '裙子', '59', '0,40,59', '1', '2018-08-08 09:02:10', '2018-08-08 09:02:10', null);

-- ----------------------------
-- Table structure for companies
-- ----------------------------
DROP TABLE IF EXISTS `companies`;
CREATE TABLE `companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of companies
-- ----------------------------
INSERT INTO `companies` VALUES ('2', '保护', '2018-07-20 14:39:39', '2018-07-20 14:39:42', null, '1');
INSERT INTO `companies` VALUES ('3', '苹果', null, '2018-07-20 08:07:00', null, '1');
INSERT INTO `companies` VALUES ('4', '保洁', '2018-07-23 09:11:12', '2018-07-23 09:11:15', null, '1');
INSERT INTO `companies` VALUES ('5', '联想', '2018-07-23 09:11:31', '2018-07-23 09:11:34', null, '1');
INSERT INTO `companies` VALUES ('6', '暴雪', '2018-07-23 09:11:52', '2018-07-23 09:11:55', null, '1');

-- ----------------------------
-- Table structure for company
-- ----------------------------
DROP TABLE IF EXISTS `company`;
CREATE TABLE `company` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `typeid` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of company
-- ----------------------------
INSERT INTO `company` VALUES ('1', 'a', '10');
INSERT INTO `company` VALUES ('2', 'a', '17');
INSERT INTO `company` VALUES ('3', 'b', '10');

-- ----------------------------
-- Table structure for couponinfos
-- ----------------------------
DROP TABLE IF EXISTS `couponinfos`;
CREATE TABLE `couponinfos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` int(10) unsigned DEFAULT NULL COMMENT '优惠券id',
  `uid` int(11) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `sfshiyong` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of couponinfos
-- ----------------------------
INSERT INTO `couponinfos` VALUES ('6', '6', '72', null, '0', '2018-08-08 15:32:25', '2018-08-08 15:32:25', null, '1');

-- ----------------------------
-- Table structure for coupons
-- ----------------------------
DROP TABLE IF EXISTS `coupons`;
CREATE TABLE `coupons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT '0' COMMENT '0不用优惠券 1用',
  `bianhao` int(10) DEFAULT NULL COMMENT '编号',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `sfshiyong` int(11) DEFAULT '0' COMMENT '是否使用优惠券 0不用 1用',
  `title` varchar(255) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of coupons
-- ----------------------------
INSERT INTO `coupons` VALUES ('6', null, null, '0', '24468', '2018-08-03 09:05:04', '2018-08-03 09:12:39', null, '6', '0', '消费满100');

-- ----------------------------
-- Table structure for fankuis
-- ----------------------------
DROP TABLE IF EXISTS `fankuis`;
CREATE TABLE `fankuis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `uname` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `content` text,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `huikui` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fankuis
-- ----------------------------
INSERT INTO `fankuis` VALUES ('13', '59', 'tangyue', '917493893', '15032071336', '1111@qq.com', '111', '2018-07-26 23:38:53', null, '2018-07-26 23:37:25', 'gun');
INSERT INTO `fankuis` VALUES ('15', '72', '15032071336', '1', '2', '3', '4', '2018-08-08 09:13:15', null, '2018-08-08 09:13:15', null);

-- ----------------------------
-- Table structure for fris
-- ----------------------------
DROP TABLE IF EXISTS `fris`;
CREATE TABLE `fris` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(30) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fris
-- ----------------------------
INSERT INTO `fris` VALUES ('21', '美酒飘香11', 'jJ9foDYQZmGwFu1FNpIp.jpg', 'http://www.baidu.com', '2018-08-07 16:42:03', '2018-08-07 16:42:03', null);
INSERT INTO `fris` VALUES ('20', 'zsg', '44fp8dGspOZfJz1L4PJl.jpg', 'http://www.baidu.com', '2018-08-07 11:38:21', '2018-08-07 11:38:21', null);

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `price` double(6,0) DEFAULT NULL,
  `sells` int(255) DEFAULT NULL,
  `stores` int(255) DEFAULT NULL,
  `descr` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `company_id` int(10) NOT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `type_id` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('1', 'aaa', 'aaa', '1', '1', '1', 'aaa', '2018-07-13 22:09:46', '2018-07-13 22:09:50', null, '1', null, '0');
INSERT INTO `goods` VALUES ('2', 'bbb', 'bbb', '2', '2', '2', 'bbb', '2018-07-13 22:10:32', '2018-07-13 22:10:35', null, '2', null, '0');
INSERT INTO `goods` VALUES ('3', 'ccc', 'ccc', '3', '3', '3', 'ccc', '2018-07-13 22:10:51', '2018-07-13 22:10:54', null, '3', null, '0');
INSERT INTO `goods` VALUES ('4', 'ddd', 'ddd', '4', '4', '4', 'ddd', '2018-07-16 22:56:03', '2018-07-16 22:56:06', null, '1', null, '0');

-- ----------------------------
-- Table structure for goods_companies
-- ----------------------------
DROP TABLE IF EXISTS `goods_companies`;
CREATE TABLE `goods_companies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` varchar(255) NOT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods_companies
-- ----------------------------
INSERT INTO `goods_companies` VALUES ('1', '10', '2,3');
INSERT INTO `goods_companies` VALUES ('2', '32', null);

-- ----------------------------
-- Table structure for guanyus
-- ----------------------------
DROP TABLE IF EXISTS `guanyus`;
CREATE TABLE `guanyus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of guanyus
-- ----------------------------
INSERT INTO `guanyus` VALUES ('9', 'bbbbb', '13211122333', '大发发发发', '2018-07-17 10:10:26', '2018-07-17 10:10:26', null);
INSERT INTO `guanyus` VALUES ('12', '张三', '13433322222', '北京市昌平区兄弟连昌平F4', '2018-07-17 11:28:43', '2018-07-17 11:28:43', null);
INSERT INTO `guanyus` VALUES ('14', '薛艳峰', '13588855222', '大哥，账号登录不上去了 ', '2018-07-18 10:16:38', '2018-07-18 10:16:38', null);
INSERT INTO `guanyus` VALUES ('16', 'zsg', '18513957339', 'aaaaaaaa', '2018-08-07 11:34:11', '2018-08-07 11:34:11', null);

-- ----------------------------
-- Table structure for histroys
-- ----------------------------
DROP TABLE IF EXISTS `histroys`;
CREATE TABLE `histroys` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '浏览商品的id',
  `pid` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=162 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of histroys
-- ----------------------------
INSERT INTO `histroys` VALUES ('136', '72', '39', '2018-08-07 22:18:33', null, '2018-08-07 22:18:33');
INSERT INTO `histroys` VALUES ('137', '72', '39', '2018-08-07 22:18:40', null, '2018-08-07 22:18:40');
INSERT INTO `histroys` VALUES ('138', '72', '38', '2018-08-07 22:18:52', null, '2018-08-07 22:18:52');
INSERT INTO `histroys` VALUES ('139', '72', '38', '2018-08-07 22:19:09', null, '2018-08-07 22:19:09');
INSERT INTO `histroys` VALUES ('140', '72', '35', '2018-08-07 22:19:13', null, '2018-08-07 22:19:13');
INSERT INTO `histroys` VALUES ('141', '72', '38', '2018-08-07 22:20:40', null, '2018-08-07 22:20:40');
INSERT INTO `histroys` VALUES ('142', '72', '38', '2018-08-07 22:20:49', null, '2018-08-07 22:20:49');
INSERT INTO `histroys` VALUES ('143', '72', '34', '2018-08-08 09:04:14', null, '2018-08-08 09:04:14');
INSERT INTO `histroys` VALUES ('144', '72', '32', '2018-08-08 09:04:27', null, '2018-08-08 09:04:27');
INSERT INTO `histroys` VALUES ('145', '72', '39', '2018-08-08 09:04:42', null, '2018-08-08 09:04:42');
INSERT INTO `histroys` VALUES ('146', '72', '39', '2018-08-08 09:05:45', null, '2018-08-08 09:05:45');
INSERT INTO `histroys` VALUES ('147', '72', '38', '2018-08-08 09:06:07', null, '2018-08-08 09:06:07');
INSERT INTO `histroys` VALUES ('148', '72', '39', '2018-08-08 09:09:20', null, '2018-08-08 09:09:20');
INSERT INTO `histroys` VALUES ('149', null, '38', '2018-08-08 14:38:41', null, '2018-08-08 14:38:41');
INSERT INTO `histroys` VALUES ('150', '72', '33', '2018-08-08 14:58:09', null, '2018-08-08 14:58:09');
INSERT INTO `histroys` VALUES ('151', '72', '34', '2018-08-08 15:02:16', null, '2018-08-08 15:02:16');
INSERT INTO `histroys` VALUES ('152', '72', '38', '2018-08-08 15:16:58', null, '2018-08-08 15:16:58');
INSERT INTO `histroys` VALUES ('153', '72', '38', '2018-08-08 15:17:33', null, '2018-08-08 15:17:33');
INSERT INTO `histroys` VALUES ('154', '72', '38', '2018-08-08 15:17:35', null, '2018-08-08 15:17:35');
INSERT INTO `histroys` VALUES ('155', '72', '38', '2018-08-08 15:18:02', null, '2018-08-08 15:18:02');
INSERT INTO `histroys` VALUES ('156', '72', '38', '2018-08-08 15:18:04', null, '2018-08-08 15:18:04');
INSERT INTO `histroys` VALUES ('157', '72', '38', '2018-08-08 15:18:38', null, '2018-08-08 15:18:38');
INSERT INTO `histroys` VALUES ('158', '72', '38', '2018-08-08 15:18:39', null, '2018-08-08 15:18:39');
INSERT INTO `histroys` VALUES ('159', '72', '38', '2018-08-08 15:18:40', null, '2018-08-08 15:18:40');
INSERT INTO `histroys` VALUES ('160', '72', '38', '2018-08-08 15:18:43', null, '2018-08-08 15:18:43');
INSERT INTO `histroys` VALUES ('161', '72', '33', '2018-08-08 15:32:33', null, '2018-08-08 15:32:33');

-- ----------------------------
-- Table structure for hostcurs
-- ----------------------------
DROP TABLE IF EXISTS `hostcurs`;
CREATE TABLE `hostcurs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `shuliang` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `fukuan` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `status` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `guige` int(10) DEFAULT NULL COMMENT '1 规格1 2是规格2 3是规格3',
  `profile` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `ddh` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=109 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hostcurs
-- ----------------------------

-- ----------------------------
-- Table structure for hostusers
-- ----------------------------
DROP TABLE IF EXISTS `hostusers`;
CREATE TABLE `hostusers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nicheng` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `token` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT '1' COMMENT '"1未激活 2激活"',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `sex` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `age` int(100) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL COMMENT '优惠券id',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hostusers
-- ----------------------------
INSERT INTO `hostusers` VALUES ('70', null, 'shuguang400@163.com', '7FphA1Te', '$2y$10$FXHyGFHCD6Wbszj5oAzTm.KcNG7XRw7odTnlfU.rGjc9Z2HMMc5sy', null, 'X0wLJBNI6S7y45AnX8cH2Pqu5c6Ag8', '2', null, null, null, null, null, null, null);
INSERT INTO `hostusers` VALUES ('71', '18513957339', '18513957339@163.com', 'e39uSrFS', '$2y$10$xV4NtvOrh6kyV.ZDBCkUsOKWV3Tdfz4DBjptXmtJpbjKa6mLGbIEC', 'SGMvBfxwnwbh9yceCrqL.jpg', 'y7Ve3kpdxiehhslJrUonHheyaSr7fE', '1', null, '2018-08-07 19:45:41', null, 'm', '5454545', '22', null);
INSERT INTO `hostusers` VALUES ('72', '15032071336', '917493893@qq.com', '唐老板', '$2y$10$NUh4EskVsRmt3DVjhRC4IOvzFsYA8wNOhdGNIH2RhL/D6y8EwjpA.', 'w7dkSUbywdIXxt2F4fvl.jpg', 'rB8ZLLjTPs8HWsu6BFjXalvQibcgyR', '2', null, '2018-08-08 08:45:05', null, 'm', '917493893', '22', null);

-- ----------------------------
-- Table structure for huodongs
-- ----------------------------
DROP TABLE IF EXISTS `huodongs`;
CREATE TABLE `huodongs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `hname` varchar(255) DEFAULT NULL,
  `hd_detail` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `price` decimal(10,0) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT NULL,
  `created_at` datetime(1) DEFAULT NULL,
  `updated_at` datetime(1) DEFAULT NULL,
  `deteled_at` datetime(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of huodongs
-- ----------------------------

-- ----------------------------
-- Table structure for infocenters
-- ----------------------------
DROP TABLE IF EXISTS `infocenters`;
CREATE TABLE `infocenters` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL COMMENT '0为未读 1为已读',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of infocenters
-- ----------------------------
INSERT INTO `infocenters` VALUES ('1', 'aa', 'bb', '57', '1', '2018-07-19 07:09:06', '2018-07-19 12:53:53', null, '2018-07-19 12:53:53');
INSERT INTO `infocenters` VALUES ('2', 'cc', 'dd', '57', '1', '2018-07-19 08:39:59', '2018-07-19 12:53:56', null, '2018-07-19 12:53:56');
INSERT INTO `infocenters` VALUES ('3', 'ee', 'ff', '57', '1', '2018-07-19 12:44:37', '2018-07-19 12:54:00', null, '2018-07-19 12:54:00');
INSERT INTO `infocenters` VALUES ('4', 'ee', 'ff', '57', '1', '2018-07-19 12:47:57', '2018-07-19 12:54:03', null, '2018-07-19 12:54:03');
INSERT INTO `infocenters` VALUES ('5', 'ee', 'ff', '57', '1', '2018-07-19 13:40:54', '2018-07-19 13:41:04', null, '2018-07-19 13:41:04');
INSERT INTO `infocenters` VALUES ('6', '请问', '请问', '60', '0', '2018-08-07 13:18:58', '2018-08-07 13:18:58', null, null);

-- ----------------------------
-- Table structure for manages
-- ----------------------------
DROP TABLE IF EXISTS `manages`;
CREATE TABLE `manages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `keywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `switch` tinyint(5) DEFAULT NULL,
  `copyright` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of manages
-- ----------------------------
INSERT INTO `manages` VALUES ('1', '美酒飘香', '酒啊', '/uploads/20180808/CQBwKt4dNPMlQYV6uxtH.png', '1', 'sssccc', null, '2018-08-08 09:10:42');

-- ----------------------------
-- Table structure for orderinfos
-- ----------------------------
DROP TABLE IF EXISTS `orderinfos`;
CREATE TABLE `orderinfos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `oid` int(11) DEFAULT NULL COMMENT '订单id',
  `pid` int(11) DEFAULT NULL COMMENT '商品id',
  `pname` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '商品名字',
  `guige` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `shuliang` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `status` int(11) DEFAULT '0' COMMENT '0未评论',
  `profile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=333 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of orderinfos
-- ----------------------------
INSERT INTO `orderinfos` VALUES ('327', '277', '34', '红酒3', '规格二', '2', '333', '2018-08-07 20:46:31', null, '2018-08-07 20:48:15', '1', '/uploads/20180807/fOUXAcxXQ7c3VSqk97sO.jpg');
INSERT INTO `orderinfos` VALUES ('328', '277', '38', '啤酒2', '规格二', '3', '99', '2018-08-07 20:46:31', null, '2018-08-07 22:25:42', '1', '/uploads/20180807/PILsGjAmMA.jpg');
INSERT INTO `orderinfos` VALUES ('329', '278', '38', '啤酒2', '规格一', '3', '99', '2018-08-07 22:19:45', null, '2018-08-07 22:20:10', '1', '/uploads/20180807/AV1ru2vY6Y.jpg');
INSERT INTO `orderinfos` VALUES ('330', '278', '35', '红酒4', '规格二', '3', '111', '2018-08-07 22:19:45', null, '2018-08-07 22:19:45', '0', '/uploads/20180807/pYBBUwKPvFotJ1zBbHrl.jpg');
INSERT INTO `orderinfos` VALUES ('331', '279', '38', '啤酒2', '规格二', '2', '99', '2018-08-08 09:07:18', null, '2018-08-08 09:07:18', '0', '/uploads/20180807/PILsGjAmMA.jpg#20180807/aVJ1243lHK.jpg#20180807/r64w1qq81p.jpg#20180807/AV1ru2vY6Y.jpg');
INSERT INTO `orderinfos` VALUES ('332', '280', '33', '红酒2', '规格二', '1', '222', '2018-08-08 15:14:52', null, '2018-08-08 15:14:52', '0', '/uploads/20180807/nOeIsfsrcucExfkENn4N.jpg');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `zongjia` int(11) DEFAULT NULL,
  `ddh` varchar(255) CHARACTER SET latin1 DEFAULT NULL COMMENT '订单号',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `address` text,
  `sfpj` int(11) DEFAULT '0',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=281 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('277', '72', '963', '3053777', '2018-08-07 20:47:58', '2018-08-07 20:46:31', null, '薛老板|15032071336|吉林省|白城市|大安市|长寿街道', '0', '2');
INSERT INTO `orders` VALUES ('278', '72', '630', '8525278', '2018-08-07 22:19:58', '2018-08-07 22:19:45', null, '薛老板|15032071336|吉林省|白城市|大安市|长寿街道', '0', '2');
INSERT INTO `orders` VALUES ('279', '72', '192', '2497650', '2018-08-08 15:35:17', '2018-08-08 09:07:18', null, '薛老板 |15032071336|吉林省|白城市|大安市|长寿街道', '0', '2');
INSERT INTO `orders` VALUES ('280', '72', '222', '4134920', '2018-08-08 15:14:52', '2018-08-08 15:14:52', null, '薛老板|15032071336|吉林省|白城市|大安市|长寿街道', '0', '0');

-- ----------------------------
-- Table structure for pingbis
-- ----------------------------
DROP TABLE IF EXISTS `pingbis`;
CREATE TABLE `pingbis` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `content` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of pingbis
-- ----------------------------
INSERT INTO `pingbis` VALUES ('1', '你,2,', null, '2018-08-07 12:29:24', null);

-- ----------------------------
-- Table structure for pinpais
-- ----------------------------
DROP TABLE IF EXISTS `pinpais`;
CREATE TABLE `pinpais` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL,
  `ppname` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `cid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pinpais
-- ----------------------------
INSERT INTO `pinpais` VALUES ('1', '26', '绿茶', '绿茶', '0', '32');
INSERT INTO `pinpais` VALUES ('2', '22', '红酒', '红酒', '0', '33');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `pname` varchar(255) DEFAULT NULL COMMENT '产品详情',
  `jieshao` text,
  `price` decimal(10,0) DEFAULT NULL,
  `shuliang` int(11) DEFAULT '1',
  `guige` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `kucun` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `profile` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `huohao` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT '0',
  `pp_id` int(11) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('32', null, '红酒1', '111', '111', '1', null, '101', '20180807/LqRgAF7jGDoATu4SJGEf.jpg#20180807/g6FcwXE2cqJk8CF78JeH.jpg#20180807/HmQ8GwQwLzEtTdMCtbBT.jpg#20180807/hOzCseO28ti8k3oybFGg.jpg', '2018-08-07 19:50:44', '2018-08-07 15:50:56', null, 'a111', '1', '1');
INSERT INTO `products` VALUES ('33', null, '红酒2', '222', '222', '1', null, '206', '20180807/nOeIsfsrcucExfkENn4N.jpg#20180807/f89XrxNjhBmP1454KagD.jpg#20180807/Ym4SMBsej3Fgt0p2lilG.jpg#20180807/DnSKIAwK6cYT8YdJX0DA.jpg', '2018-08-08 15:32:37', '2018-08-07 15:51:26', null, 'a222', '1', '1');
INSERT INTO `products` VALUES ('34', null, '红酒3', '333', '333', '1', null, '210', '20180807/fOUXAcxXQ7c3VSqk97sO.jpg#20180807/0Jx3JsHMX3M4xFbp4XID.jpg#20180807/i6beevJ0wm1DqqJI7ayj.jpg#20180807/YSIzqm4JlMVAzzz7sGKo.jpeg', '2018-08-07 19:36:08', '2018-08-07 15:51:54', null, 'a2223', '1', '1');
INSERT INTO `products` VALUES ('35', null, '红酒4', 'fefew', '111', '1', null, '222', '20180807/pYBBUwKPvFotJ1zBbHrl.jpg#20180807/yF2jD2KTqxSaeJWEzs6Q.jpg#20180807/scIVk7udsipBs9dqgoUK.jpg#20180807/mLX3bCrSxF4VsDEpVTjd.jpg', '2018-08-07 15:52:24', '2018-08-07 15:52:24', null, 'a111', '1', '1');
INSERT INTO `products` VALUES ('36', null, 'hongjiu', 'w', '111', '1', null, '222', '20180807/cIXAgMVdJsqvXgbEa1Yx.jpg#20180807/JbenpwW0MxaMNVwXiZNO.jpg#20180807/unBfxrRjyhQKB3zMHgYh.jpeg#20180807/CKJLbpX9WUVDoGBkzvHp.jpg', '2018-08-07 15:52:54', '2018-08-07 15:52:54', null, 'a111222', '3', '1');
INSERT INTO `products` VALUES ('37', null, 'hongjiufdg', '<p>&nbsp; &nbsp; &nbsp; 		&lt;p&gt;ffwf&lt;/p&gt;		\r\n &nbsp; &nbsp;	</p>', '333', '1', null, '217', '20180807/KTIgdvm9k6.jpg#20180807/yCf6DGeVdA.jpg#20180807/3O8If6dMEs.jpeg#20180807/URxkkDoDkq.jpg', '2018-08-07 16:51:25', '2018-08-07 15:54:40', null, 'a11123', '0', '1');
INSERT INTO `products` VALUES ('38', null, '啤酒2', '<p>123132</p>', '99', '1', null, '1232', '20180807/PILsGjAmMA.jpg#20180807/aVJ1243lHK.jpg#20180807/r64w1qq81p.jpg#20180807/AV1ru2vY6Y.jpg', '2018-08-08 09:06:10', '2018-08-07 18:27:50', null, 'B123456', '0', '1');
INSERT INTO `products` VALUES ('39', null, '法国红酒', '<p>商品名称：法国红酒 卡特尔波尔多优质干红葡萄酒 超级波尔多进口AOC 750mlx6瓶 整箱装商品编号：1378700118店铺： 澄意生活旗舰店商品毛重：8.0kg商品产地：法国货号：5166843酸度：低酸类型：静止酒国产/进口：进口口感：饱满颜色：宝石红包装：整箱特性：AOC/AOP容量：750mL以上甜度：干型葡萄品种：赤霞珠（Cabernet Sauvignon），梅洛（Merlot），品丽珠（Cabernet Franc）分类：红葡萄酒香型：花香，果香适用场景：家庭聚会，礼节拜访，</p>', '33', '1', null, '1234', '20180807/9HETvXU0D8.jpg#20180807/ZlWNifX3tq.jpg#20180807/dNXW3YvqJ3.jpg#20180807/AmZT6aRqz4.jpg', '2018-08-07 20:14:28', '2018-08-07 20:14:28', null, 'B654321', '0', '1');

-- ----------------------------
-- Table structure for shoppingjias
-- ----------------------------
DROP TABLE IF EXISTS `shoppingjias`;
CREATE TABLE `shoppingjias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL COMMENT '商品id',
  `uid` int(11) DEFAULT NULL COMMENT '用户id',
  `did` int(11) DEFAULT NULL COMMENT '订单id',
  `uname` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `profile` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `pingfen` varchar(255) CHARACTER SET latin1 DEFAULT NULL,
  `content` text,
  `created_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=247 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of shoppingjias
-- ----------------------------
INSERT INTO `shoppingjias` VALUES ('241', '34', '69', '273', '15032071336@163.com', '/uploads/20180807/fOUXAcxXQ7c3VSqk97sO.jpg#20180807/0Jx3JsHMX3M4xFbp4XID.jpg#20180807/i6beevJ0wm1DqqJI7ayj.jpg#20180807/YSIzqm4JlMVAzzz7sGKo.jpeg', null, '11231156', '2018-08-07 19:36:50', null, '2018-08-07 19:36:50');
INSERT INTO `shoppingjias` VALUES ('242', '33', '70', '275', 'shuguang400@163.com', '/uploads/20180807/nOeIsfsrcucExfkENn4N.jpg#20180807/f89XrxNjhBmP1454KagD.jpg#20180807/Ym4SMBsej3Fgt0p2lilG.jpg#20180807/DnSKIAwK6cYT8YdJX0DA.jpg', null, '23223', '2018-08-07 19:52:33', null, '2018-08-07 19:52:33');
INSERT INTO `shoppingjias` VALUES ('243', '33', '72', '276', '917493893@qq.com', '/uploads/20180807/nOeIsfsrcucExfkENn4N.jpg', null, '好喝111', '2018-08-07 20:39:18', null, '2018-08-07 20:39:18');
INSERT INTO `shoppingjias` VALUES ('244', '34', '72', '277', '917493893@qq.com', '/uploads/20180807/fOUXAcxXQ7c3VSqk97sO.jpg', null, '红酒不好喝', '2018-08-07 20:48:15', null, '2018-08-07 20:48:15');
INSERT INTO `shoppingjias` VALUES ('245', '38', '72', '278', '917493893@qq.com', '/uploads/20180807/AV1ru2vY6Y.jpg', null, '1234', '2018-08-07 22:20:10', null, '2018-08-07 22:20:10');
INSERT INTO `shoppingjias` VALUES ('246', '38', '72', '277', '917493893@qq.com', '/uploads/20180807/PILsGjAmMA.jpg', null, '气温气温', '2018-08-07 22:25:42', null, '2018-08-07 22:25:42');

-- ----------------------------
-- Table structure for shoucangs
-- ----------------------------
DROP TABLE IF EXISTS `shoucangs`;
CREATE TABLE `shoucangs` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(11) DEFAULT NULL,
  `pname` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=sjis;

-- ----------------------------
-- Records of shoucangs
-- ----------------------------
INSERT INTO `shoucangs` VALUES ('12', '34', '红酒3', '72', '/uploads/20180807/YSIzqm4JlMVAzzz7sGKo.jpeg', '333', '2018-08-08 15:02:20', null, '2018-08-08 15:02:20', '1');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uname` varchar(255) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `pic` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `psword` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('31', 'zhangshuguang', '张曙广', '/uploads/20180807/IcQCwv7JiQ9cFiLbfpu0.jpg', '15032071336', '123456@qq.com', '2018-08-02 13:58:31', '2018-08-07 10:31:48', null, '$2y$10$mTp0vyvjhmgMHKl3rMcZAeSSgy8VMYHa8pfS4cagF2svX4clinLqK');
INSERT INTO `users` VALUES ('32', 'tangyue1', '唐跃', '/uploads/20180807/6leuDfuxnGlPB29YOFoo.jpg', '18513957339', '18513957339@163.com', '2018-08-07 16:57:50', '2018-08-07 16:57:50', null, '$2y$10$XzXcPzz2KPdnjFwauZVR2eFUgtQhjZFZ4TTvDywnIjFArd0WnDUgW');
